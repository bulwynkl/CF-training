# A Cloud Guru - Advanced Cloud Formation
Prepared by Adrian Cantrill 2016

(c) A Cloud Guru 2016, 2019
Lab files for A Cloud Guru - Advanced CloudFormation Course

Please note, this is provided as-is, neither I, nor A Cloud Guru support this code. If you do identify any errors, then please identify and we will attempt to fix on a best efforts basis.

## aCloud.Guru
This file was created for the purposes of the Advanced Cloud Formation Course from [ACloud.Guru](https://acloud.guru)

## IMPORTANT
These files are distributed on an AS IS BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied

## Updated:
- Dec 2017 - Ported to this new Repo
- Jan 2019 - revised AMIs to Jan 2019, updated template names to make the Linux(1) version clear, and small tweaks to the scripts to fix minor bugs.


